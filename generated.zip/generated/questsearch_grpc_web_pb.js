

const grpc = {};
grpc.web = require('grpc-web');

const proto = {};
proto.questionService = require('./questsearch_pb.js');

proto.questionService.QuestionServiceClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options.format = 'text';

  
  this.hostname_ = hostname.replace(/\/+$/, '');

};



proto.questionService.QuestionServicePromiseClient =
    function(hostname, credentials, options) {
  if (!options) options = {};
  options.format = 'text';

  
  this.hostname_ = hostname.replace(/\/+$/, '');

};



const methodDescriptor_QuestionService_GetQuestions = new grpc.web.MethodDescriptor(
  '/questionService.QuestionService/GetQuestions',
  grpc.web.MethodType.UNARY,
  proto.questionService.GetQuestionsRequest,
  proto.questionService.GetQuestionsResponse,
  
  function(request) {
    return request.serializeBinary();
  },
  proto.questionService.GetQuestionsResponse.deserializeBinary
);



proto.questionService.QuestionServiceClient.prototype.getQuestions =
    function(request, metadata, callback) {
  return this.client_.rpcCall(this.hostname_ +
      '/questionService.QuestionService/GetQuestions',
      request,
      metadata || {},
      methodDescriptor_QuestionService_GetQuestions,
      callback);
};


proto.questionService.QuestionServicePromiseClient.prototype.getQuestions =
    function(request, metadata) {
  return this.client_.unaryCall(this.hostname_ +
      '/questionService.QuestionService/GetQuestions',
      request,
      metadata || {},
      methodDescriptor_QuestionService_GetQuestions);
};


module.exports = proto.questionService;

