// source: questions.proto
/**
 * @fileoverview
 * @enhanceable
 * @suppress {missingRequire} reports error on implicit type usages.
 * @suppress {messageConventions} JS Compiler reports an error if a variable or
 *     field starts with 'MSG_' and isn't a translatable message.
 * @public
 */
// GENERATED CODE -- DO NOT EDIT!
/* eslint-disable */
// @ts-nocheck

var jspb = require('google-protobuf');
var goog = jspb;
var global =
    (typeof globalThis !== 'undefined' && globalThis) ||
    (typeof window !== 'undefined' && window) ||
    (typeof global !== 'undefined' && global) ||
    (typeof self !== 'undefined' && self) ||
    (function () { return this; }).call(null) ||
    Function('return this')();

goog.exportSymbol('proto.questionService.Block', null, global);
goog.exportSymbol('proto.questionService.GetQuestionsRequest', null, global);
goog.exportSymbol('proto.questionService.GetQuestionsResponse', null, global);
goog.exportSymbol('proto.questionService.Option', null, global);
goog.exportSymbol('proto.questionService.Question', null, global);


proto.questionService.Question = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.questionService.Question.repeatedFields_, null);
};
goog.inherits(proto.questionService.Question, jspb.Message);
if (goog.DEBUG && !COMPILED) {

  proto.questionService.Question.displayName = 'proto.questionService.Question';
}


proto.questionService.Block = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.questionService.Block, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.questionService.Block.displayName = 'proto.questionService.Block';
}


proto.questionService.Option = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.questionService.Option, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.questionService.Option.displayName = 'proto.questionService.Option';
}

proto.questionService.GetQuestionsRequest = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, null, null);
};
goog.inherits(proto.questionService.GetQuestionsRequest, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.questionService.GetQuestionsRequest.displayName = 'proto.questionService.GetQuestionsRequest';
}


proto.questionService.GetQuestionsResponse = function(opt_data) {
  jspb.Message.initialize(this, opt_data, 0, -1, proto.questionService.GetQuestionsResponse.repeatedFields_, null);
};
goog.inherits(proto.questionService.GetQuestionsResponse, jspb.Message);
if (goog.DEBUG && !COMPILED) {
  /**
   * @public
   * @override
   */
  proto.questionService.GetQuestionsResponse.displayName = 'proto.questionService.GetQuestionsResponse';
}

proto.questionService.Question.repeatedFields_ = [4,5];



if (jspb.Message.GENERATE_TO_OBJECT) {

proto.questionService.Question.prototype.toObject = function(opt_includeInstance) {
  return proto.questionService.Question.toObject(opt_includeInstance, this);
};



proto.questionService.Question.toObject = function(includeInstance, msg) {
  var f, obj = {
id: jspb.Message.getFieldWithDefault(msg, 1, ""),
type: jspb.Message.getFieldWithDefault(msg, 2, ""),
anagramtype: jspb.Message.getFieldWithDefault(msg, 3, ""),
blocksList: jspb.Message.toObjectList(msg.getBlocksList(),
    proto.questionService.Block.toObject, includeInstance),
optionsList: jspb.Message.toObjectList(msg.getOptionsList(),
    proto.questionService.Option.toObject, includeInstance),
siblingid: jspb.Message.getFieldWithDefault(msg, 6, ""),
solution: jspb.Message.getFieldWithDefault(msg, 7, ""),
title: jspb.Message.getFieldWithDefault(msg, 8, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}



proto.questionService.Question.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.questionService.Question;
  return proto.questionService.Question.deserializeBinaryFromReader(msg, reader);
};



proto.questionService.Question.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readString());
      msg.setId(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readString());
      msg.setType(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readString());
      msg.setAnagramtype(value);
      break;
    case 4:
      var value = new proto.questionService.Block;
      reader.readMessage(value,proto.questionService.Block.deserializeBinaryFromReader);
      msg.addBlocks(value);
      break;
    case 5:
      var value = new proto.questionService.Option;
      reader.readMessage(value,proto.questionService.Option.deserializeBinaryFromReader);
      msg.addOptions(value);
      break;
    case 6:
      var value = /** @type {string} */ (reader.readString());
      msg.setSiblingid(value);
      break;
    case 7:
      var value = /** @type {string} */ (reader.readString());
      msg.setSolution(value);
      break;
    case 8:
      var value = /** @type {string} */ (reader.readString());
      msg.setTitle(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};


/**
 * Serializes the message to binary data (in protobuf wire format).
 * @return {!Uint8Array}
 */
proto.questionService.Question.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.questionService.Question.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};



proto.questionService.Question.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getId();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getType();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
  f = message.getAnagramtype();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
  f = message.getBlocksList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      4,
      f,
      proto.questionService.Block.serializeBinaryToWriter
    );
  }
  f = message.getOptionsList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      5,
      f,
      proto.questionService.Option.serializeBinaryToWriter
    );
  }
  f = message.getSiblingid();
  if (f.length > 0) {
    writer.writeString(
      6,
      f
    );
  }
  f = message.getSolution();
  if (f.length > 0) {
    writer.writeString(
      7,
      f
    );
  }
  f = message.getTitle();
  if (f.length > 0) {
    writer.writeString(
      8,
      f
    );
  }
};


/**
 * optional string id = 1;
 * @return {string}
 */
proto.questionService.Question.prototype.getId = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};


/**
 * @param {string} value
 * @return {!proto.questionService.Question} returns this
 */
proto.questionService.Question.prototype.setId = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};


/**
 * optional string type = 2;
 * @return {string}
 */
proto.questionService.Question.prototype.getType = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


/**
 * @param {string} value
 * @return {!proto.questionService.Question} returns this
 */
proto.questionService.Question.prototype.setType = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};


proto.questionService.Question.prototype.getAnagramtype = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};



proto.questionService.Question.prototype.setAnagramtype = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};



proto.questionService.Question.prototype.getBlocksList = function() {
  return /** @type{!Array<!proto.questionService.Block>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.questionService.Block, 4));
};



proto.questionService.Question.prototype.setBlocksList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 4, value);
};


proto.questionService.Question.prototype.addBlocks = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 4, opt_value, proto.questionService.Block, opt_index);
};



proto.questionService.Question.prototype.clearBlocksList = function() {
  return this.setBlocksList([]);
};



proto.questionService.Question.prototype.getOptionsList = function() {
  return /** @type{!Array<!proto.questionService.Option>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.questionService.Option, 5));
};



proto.questionService.Question.prototype.setOptionsList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 5, value);
};



proto.questionService.Question.prototype.addOptions = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 5, opt_value, proto.questionService.Option, opt_index);
};



proto.questionService.Question.prototype.clearOptionsList = function() {
  return this.setOptionsList([]);
};


proto.questionService.Question.prototype.getSiblingid = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 6, ""));
};


proto.questionService.Question.prototype.setSiblingid = function(value) {
  return jspb.Message.setProto3StringField(this, 6, value);
};


proto.questionService.Question.prototype.getSolution = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 7, ""));
};


proto.questionService.Question.prototype.setSolution = function(value) {
  return jspb.Message.setProto3StringField(this, 7, value);
};



proto.questionService.Question.prototype.getTitle = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 8, ""));
};



proto.questionService.Question.prototype.setTitle = function(value) {
  return jspb.Message.setProto3StringField(this, 8, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {

proto.questionService.Block.prototype.toObject = function(opt_includeInstance) {
  return proto.questionService.Block.toObject(opt_includeInstance, this);
};



proto.questionService.Block.toObject = function(includeInstance, msg) {
  var f, obj = {
text: jspb.Message.getFieldWithDefault(msg, 1, ""),
showinoption: jspb.Message.getBooleanFieldWithDefault(msg, 2, false),
isanswer: jspb.Message.getBooleanFieldWithDefault(msg, 3, false)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}



proto.questionService.Block.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.questionService.Block;
  return proto.questionService.Block.deserializeBinaryFromReader(msg, reader);
};



proto.questionService.Block.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readString());
      msg.setText(value);
      break;
    case 2:
      var value = /** @type {boolean} */ (reader.readBool());
      msg.setShowinoption(value);
      break;
    case 3:
      var value = /** @type {boolean} */ (reader.readBool());
      msg.setIsanswer(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};



proto.questionService.Block.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.questionService.Block.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};


proto.questionService.Block.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getText();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getShowinoption();
  if (f) {
    writer.writeBool(
      2,
      f
    );
  }
  f = message.getIsanswer();
  if (f) {
    writer.writeBool(
      3,
      f
    );
  }
};



proto.questionService.Block.prototype.getText = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};



proto.questionService.Block.prototype.setText = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};



proto.questionService.Block.prototype.getShowinoption = function() {
  return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 2, false));
};



proto.questionService.Block.prototype.setShowinoption = function(value) {
  return jspb.Message.setProto3BooleanField(this, 2, value);
};



proto.questionService.Block.prototype.getIsanswer = function() {
  return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 3, false));
};



proto.questionService.Block.prototype.setIsanswer = function(value) {
  return jspb.Message.setProto3BooleanField(this, 3, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {

proto.questionService.Option.prototype.toObject = function(opt_includeInstance) {
  return proto.questionService.Option.toObject(opt_includeInstance, this);
};



proto.questionService.Option.toObject = function(includeInstance, msg) {
  var f, obj = {
text: jspb.Message.getFieldWithDefault(msg, 1, ""),
iscorrect: jspb.Message.getBooleanFieldWithDefault(msg, 2, false)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}



proto.questionService.Option.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.questionService.Option;
  return proto.questionService.Option.deserializeBinaryFromReader(msg, reader);
};



proto.questionService.Option.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {string} */ (reader.readString());
      msg.setText(value);
      break;
    case 2:
      var value = /** @type {boolean} */ (reader.readBool());
      msg.setIscorrect(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};



proto.questionService.Option.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.questionService.Option.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};



proto.questionService.Option.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getText();
  if (f.length > 0) {
    writer.writeString(
      1,
      f
    );
  }
  f = message.getIscorrect();
  if (f) {
    writer.writeBool(
      2,
      f
    );
  }
};



proto.questionService.Option.prototype.getText = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 1, ""));
};



proto.questionService.Option.prototype.setText = function(value) {
  return jspb.Message.setProto3StringField(this, 1, value);
};



proto.questionService.Option.prototype.getIscorrect = function() {
  return /** @type {boolean} */ (jspb.Message.getBooleanFieldWithDefault(this, 2, false));
};



proto.questionService.Option.prototype.setIscorrect = function(value) {
  return jspb.Message.setProto3BooleanField(this, 2, value);
};





if (jspb.Message.GENERATE_TO_OBJECT) {

proto.questionService.GetQuestionsRequest.prototype.toObject = function(opt_includeInstance) {
  return proto.questionService.GetQuestionsRequest.toObject(opt_includeInstance, this);
};



proto.questionService.GetQuestionsRequest.toObject = function(includeInstance, msg) {
  var f, obj = {
page: jspb.Message.getFieldWithDefault(msg, 1, 0),
type: jspb.Message.getFieldWithDefault(msg, 2, ""),
title: jspb.Message.getFieldWithDefault(msg, 3, "")
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}



proto.questionService.GetQuestionsRequest.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.questionService.GetQuestionsRequest;
  return proto.questionService.GetQuestionsRequest.deserializeBinaryFromReader(msg, reader);
};



proto.questionService.GetQuestionsRequest.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {number} */ (reader.readInt32());
      msg.setPage(value);
      break;
    case 2:
      var value = /** @type {string} */ (reader.readString());
      msg.setType(value);
      break;
    case 3:
      var value = /** @type {string} */ (reader.readString());
      msg.setTitle(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};



proto.questionService.GetQuestionsRequest.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.questionService.GetQuestionsRequest.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};



proto.questionService.GetQuestionsRequest.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getPage();
  if (f !== 0) {
    writer.writeInt32(
      1,
      f
    );
  }
  f = message.getType();
  if (f.length > 0) {
    writer.writeString(
      2,
      f
    );
  }
  f = message.getTitle();
  if (f.length > 0) {
    writer.writeString(
      3,
      f
    );
  }
};



proto.questionService.GetQuestionsRequest.prototype.getPage = function() {
  return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};



proto.questionService.GetQuestionsRequest.prototype.setPage = function(value) {
  return jspb.Message.setProto3IntField(this, 1, value);
};


proto.questionService.GetQuestionsRequest.prototype.getType = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 2, ""));
};


proto.questionService.GetQuestionsRequest.prototype.setType = function(value) {
  return jspb.Message.setProto3StringField(this, 2, value);
};



proto.questionService.GetQuestionsRequest.prototype.getTitle = function() {
  return /** @type {string} */ (jspb.Message.getFieldWithDefault(this, 3, ""));
};



proto.questionService.GetQuestionsRequest.prototype.setTitle = function(value) {
  return jspb.Message.setProto3StringField(this, 3, value);
};




proto.questionService.GetQuestionsResponse.repeatedFields_ = [4];



if (jspb.Message.GENERATE_TO_OBJECT) {

proto.questionService.GetQuestionsResponse.prototype.toObject = function(opt_includeInstance) {
  return proto.questionService.GetQuestionsResponse.toObject(opt_includeInstance, this);
};



proto.questionService.GetQuestionsResponse.toObject = function(includeInstance, msg) {
  var f, obj = {
total: jspb.Message.getFieldWithDefault(msg, 1, 0),
page: jspb.Message.getFieldWithDefault(msg, 2, 0),
pagesize: jspb.Message.getFieldWithDefault(msg, 3, 0),
dataList: jspb.Message.toObjectList(msg.getDataList(),
    proto.questionService.Question.toObject, includeInstance)
  };

  if (includeInstance) {
    obj.$jspbMessageInstance = msg;
  }
  return obj;
};
}



proto.questionService.GetQuestionsResponse.deserializeBinary = function(bytes) {
  var reader = new jspb.BinaryReader(bytes);
  var msg = new proto.questionService.GetQuestionsResponse;
  return proto.questionService.GetQuestionsResponse.deserializeBinaryFromReader(msg, reader);
};



proto.questionService.GetQuestionsResponse.deserializeBinaryFromReader = function(msg, reader) {
  while (reader.nextField()) {
    if (reader.isEndGroup()) {
      break;
    }
    var field = reader.getFieldNumber();
    switch (field) {
    case 1:
      var value = /** @type {number} */ (reader.readInt32());
      msg.setTotal(value);
      break;
    case 2:
      var value = /** @type {number} */ (reader.readInt32());
      msg.setPage(value);
      break;
    case 3:
      var value = /** @type {number} */ (reader.readInt32());
      msg.setPagesize(value);
      break;
    case 4:
      var value = new proto.questionService.Question;
      reader.readMessage(value,proto.questionService.Question.deserializeBinaryFromReader);
      msg.addData(value);
      break;
    default:
      reader.skipField();
      break;
    }
  }
  return msg;
};



proto.questionService.GetQuestionsResponse.prototype.serializeBinary = function() {
  var writer = new jspb.BinaryWriter();
  proto.questionService.GetQuestionsResponse.serializeBinaryToWriter(this, writer);
  return writer.getResultBuffer();
};



proto.questionService.GetQuestionsResponse.serializeBinaryToWriter = function(message, writer) {
  var f = undefined;
  f = message.getTotal();
  if (f !== 0) {
    writer.writeInt32(
      1,
      f
    );
  }
  f = message.getPage();
  if (f !== 0) {
    writer.writeInt32(
      2,
      f
    );
  }
  f = message.getPagesize();
  if (f !== 0) {
    writer.writeInt32(
      3,
      f
    );
  }
  f = message.getDataList();
  if (f.length > 0) {
    writer.writeRepeatedMessage(
      4,
      f,
      proto.questionService.Question.serializeBinaryToWriter
    );
  }
};



proto.questionService.GetQuestionsResponse.prototype.getTotal = function() {
  return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 1, 0));
};



proto.questionService.GetQuestionsResponse.prototype.setTotal = function(value) {
  return jspb.Message.setProto3IntField(this, 1, value);
};



proto.questionService.GetQuestionsResponse.prototype.getPage = function() {
  return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 2, 0));
};



proto.questionService.GetQuestionsResponse.prototype.setPage = function(value) {
  return jspb.Message.setProto3IntField(this, 2, value);
};



proto.questionService.GetQuestionsResponse.prototype.getPagesize = function() {
  return /** @type {number} */ (jspb.Message.getFieldWithDefault(this, 3, 0));
};



proto.questionService.GetQuestionsResponse.prototype.setPagesize = function(value) {
  return jspb.Message.setProto3IntField(this, 3, value);
};



proto.questionService.GetQuestionsResponse.prototype.getDataList = function() {
  return /** @type{!Array<!proto.questionService.Question>} */ (
    jspb.Message.getRepeatedWrapperField(this, proto.questionService.Question, 4));
};



proto.questionService.GetQuestionsResponse.prototype.setDataList = function(value) {
  return jspb.Message.setRepeatedWrapperField(this, 4, value);
};



proto.questionService.GetQuestionsResponse.prototype.addData = function(opt_value, opt_index) {
  return jspb.Message.addToRepeatedWrapperField(this, 4, opt_value, proto.questionService.Question, opt_index);
};



proto.questionService.GetQuestionsResponse.prototype.clearDataList = function() {
  return this.setDataList([]);
};


goog.object.extend(exports, proto.questionService);
