const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const path = require('path');
const dotenv = require('dotenv');
const connectDB = require('./db'); // Import the connectDB function
const { getQuestions } = require('./services/questions');

dotenv.config(); // Load environment variables from .env

// Connect to MongoDB before starting the server
connectDB(); 

// Load gRPC Protobuf
const protoPath = path.join(__dirname, '../protos/questions.proto');
const packageDefinition = protoLoader.loadSync(protoPath);
const questionsProto = grpc.loadPackageDefinition(packageDefinition).QuestionService;

// Define the gRPC server
const server = new grpc.Server();

// Implement the getQuestions service
server.addService(questionsProto.service, {
  getQuestions: async (call, callback) => {
    try {
      const questions = await getQuestions(); // This will fetch questions from MongoDB later
      callback(null, { questions });
    } catch (error) {
      callback(error, null);
    }
  }
});

const serverAddress = '0.0.0.0:50051';
server.bindAsync(
  serverAddress,
  grpc.ServerCredentials.createInsecure(),
  (error, port) => {
    if (error) {
      console.error('Failed to bind gRPC server:', error.message);
      process.exit(1); // Exit the process if server binding fails
    }
    console.log(`gRPC server running at ${serverAddress}`);
   // Start the server only after successful binding
  }
);


