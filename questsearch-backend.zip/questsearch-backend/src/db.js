const mongoose = require('mongoose');

// This function connects to MongoDB using the connection string stored in the .env file.
const connectDB = async () => {
  try {
    // Use the connection string stored in the .env file
    await mongoose.connect(process.env.MONGO_URI );

    // If the connection is successful
    console.log('MongoDB connected');
  } catch (error) {
    // If there's an error during the connection
    console.error('Error connecting to MongoDB:', error);
    process.exit(1); // Exit the process with failure status
  }
};

// Export the connectDB function to be used in other parts of the app (like server.js)
module.exports = connectDB;
