const Question = require('../models');  // Import the Question model

// This function fetches questions from MongoDB
const getQuestions = async () => {
  try {
    // Fetch all questions from the database
    const questions = await Question.find(); // This will return all questions from MongoDB
    return questions;
  } catch (error) {
    console.error('Error fetching questions from DB:', error);
    return [];
  }
};

module.exports = { getQuestions };
