const mongoose = require('mongoose');

// Define the Question schema
const questionSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  questionType: {
    type: String,
    required: true
  },
  // Add any other fields you need
});

// Create the Question model
const Question = mongoose.model('Question', questionSchema);

module.exports = Question;
