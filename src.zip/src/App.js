import React, { useState } from 'react';
import './App.css';
import { QuestionServiceClient } from './generated/questsearch_grpc_web_pb';
import { QuestionRequest } from './generated/questsearch_pb';
import SearchBox from './components/searchbox.js';
import SearchResults from './components/searchbox.js';

const client = new QuestionServiceClient('http://localhost:8080', null, null); // gRPC-web client

function App() {
  const [query, setQuery] = useState('');
  const [type, setType] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchQuestions = () => {
    setLoading(true);
    setError('');
    
    // Create the request object
    const request = new QuestionRequest();
    request.setTitle(query);
    request.setType(type);

    client.getQuestions(request, {}, (err, response) => {
      if (err) {
        setError('Error fetching data');
      } else {
        setResults(response.getQuestionsList());
      }
      setLoading(false);
    });
  };

  return (
    <div className="App">
      <h1>Question Search</h1>
      <SearchBox query={query} setQuery={setQuery} setType={setType} fetchQuestions={fetchQuestions} />
      {loading && <p>Loading...</p>}
      {error && <p>{error}</p>}
      <SearchResults results={results} />
    </div>
  );
}

export default App;
