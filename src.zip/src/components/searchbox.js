import React from 'react';

const SearchResults = ({ results }) => {
  return (
    <div className="search-results">
      {results.length === 0 ? (
        <p>No results found.</p>
      ) : (
        results.map((result) => (
          <div key={result._id} className="result-item">
            <h3>{result.title}</h3>
            <p><strong>Type:</strong> {result.type}</p>
            {result.type === 'MCQ' && (
              <div>
                <p><strong>Options:</strong></p>
                <ul>
                  {result.options.map((option, index) => (
                    <li key={index}>{option}</li>
                  ))}
                </ul>
              </div>
            )}
            {result.type === 'ANAGRAM' && (
              <p><strong>Solution:</strong> {result.solution}</p>
            )}
          </div>
        ))
      )}
    </div>
  );
};

export default SearchResults;
