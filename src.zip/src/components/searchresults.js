import React from 'react';

const SearchResults = ({ results }) => {
  return (
    <div className="search-results">
      {results.length === 0 ? (
        <p>No results found.</p>
      ) : (
        results.map((question) => (
          <div key={question._id} className="question-item">
            <h3>{question.title}</h3>
            <p><strong>Type:</strong> {question.type}</p>

            {/* Render different components based on the question type */}
            {question.type === 'ANAGRAM' && (
              <div>
                <p><strong>Anagram Type:</strong> {question.anagramType}</p>
                <p><strong>Solution:</strong> {question.solution}</p>
              </div>
            )}

            {question.type === 'MCQ' && (
              <div>
                <p><strong>Options:</strong></p>
                <ul>
                  {question.options && question.options.map((option, index) => (
                    <li key={index}>{option}</li>
                  ))}
                </ul>
              </div>
            )}

            {question.type === 'READ_ALONG' && (
              <div>
                <p><strong>Read Along Content:</strong> {question.title}</p>
                {/* Add additional content if needed */}
              </div>
            )}

            {question.type === 'CONTENT_ONLY' && (
              <div>
                <p><strong>Content:</strong> {question.title}</p>
                {/* Add any extra content here if necessary */}
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
};

export default SearchResults;
